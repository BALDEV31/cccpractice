<?php
class BmiCalculator_Model_Resource_Collection_BmiCalculator extends Core_Model_Resource_Collection_Abstract{
    
}
?>
<?php class Banner_Model_Resource_Collection_Banner extends Core_Model_Resource_Collection_Abstract{
    
}
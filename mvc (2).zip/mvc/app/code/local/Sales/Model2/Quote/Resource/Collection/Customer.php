<?php
class Sales_Model_Quote_Resource_Collection_Customer extends Core_Model_Resource_Collection_Abstract{
    
}
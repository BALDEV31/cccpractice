<?php
class Sales_Controller_Quote extends Core_Controller_Front_Action
{
    public function addAction()
    {
        $data = $this->getRequest()->getParams('cart');
        $request = $data;
        $quote = Mage::getSingleton("sales/quote")
            ->addProduct($request);
        $this->setRedirect('cart/index/view');
    }

    public function deleteAction()
    {
        $id = $this->getRequest()->getParams("id");
        $quote = Mage::getSingleton("sales/quote")->deleteProduct($id);
        $this->setRedirect('cart/index/view');
    }

    public function updateAction()
    {
        $data = $this->getRequest()->getParams();
        $request = ['product_id' => $data['product_id'], 'quantity' => $data['quantity']];
        $quote = Mage::getSingleton("sales/quote")
            ->updateProduct($request);
        $this->setRedirect("cart/index/view");
    }

    public function addressAction(){
        echo "<pre>";
        $data = $this->getRequest()->getParams("customer_address");
       Mage::getSingleton('sales/quote')->addAddress($data);
    }
}

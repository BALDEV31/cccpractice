<?php
class Customer_Block_Account_ForgotPassword extends Core_Block_Template{
    public function __construct(){
        $this->setTemplate("customer/account/forgotpassword.phtml");
    }
}